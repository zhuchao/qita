<?php
define("_INSTALL_PATH_", __DIR__);
define("APP_DEBUG",true);
require_once "..".DIRECTORY_SEPARATOR.'Core'.DIRECTORY_SEPARATOR.'init.php';
require_once "..".DIRECTORY_SEPARATOR.'Core'.DIRECTORY_SEPARATOR.'core.php';

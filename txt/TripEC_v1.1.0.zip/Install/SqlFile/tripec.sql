SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE `jee_admin_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login_name` varchar(50) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  `true_name` varchar(50) DEFAULT NULL,
  `tel` varchar(50) DEFAULT NULL,
  `adre` varchar(50) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `last_login_time` int(11) DEFAULT NULL,
  `last_login_ip` varchar(255) DEFAULT NULL,
  `login_count` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_advert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `area_id` int(11) NOT NULL,
  `types` tinyint(1) DEFAULT NULL,
  `start_time` int(11) DEFAULT NULL,
  `end_time` int(11) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `s_pic` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='广告管理' ;

CREATE TABLE `jee_advert_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(50) NOT NULL,
  `names_en` varchar(50) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='广告展示区域' ;

CREATE TABLE `jee_area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `paths` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `levels` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `names_en` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publish_id` int(11) NOT NULL,
  `cid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `pic` varchar(200) DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1',
  `link` varchar(255) DEFAULT NULL,
  `source` varchar(100) NOT NULL DEFAULT '本站',
  `source_url` varchar(255) NOT NULL DEFAULT '#',
  `content` text,
  `add_time` int(11) NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='文章管理' ;

CREATE TABLE `jee_article_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT '0',
  `names` varchar(50) NOT NULL,
  `e_names` varchar(50) NOT NULL,
  `memo` varchar(50) DEFAULT NULL,
  `model` smallint(1) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(2) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='文章分类管理' ;

CREATE TABLE `jee_base_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sort` int(11) DEFAULT NULL,
  `config_key` varchar(200) DEFAULT NULL,
  `config_value` varchar(200) DEFAULT NULL,
  `memo` varchar(200) DEFAULT NULL,
  `isdel` int(11) DEFAULT '0' COMMENT '0:允许删除,1：不允许删除',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=gb2312 ;

CREATE TABLE `jee_cash_coupon` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `serial_num` varchar(32) NOT NULL DEFAULT '' COMMENT '代金券序列号',
  `coupon_value` int(11) NOT NULL DEFAULT '0' COMMENT '代金券额',
  `creator_id` int(11) NOT NULL COMMENT '代金券创建者',
  `create_time` int(11) NOT NULL DEFAULT '0' COMMENT '代金券创建时间',
  `expire_time` int(11) NOT NULL DEFAULT '0' COMMENT '代金券过期时间',
  `use_userid` int(11) DEFAULT NULL COMMENT '使用者',
  `use_time` int(11) DEFAULT NULL COMMENT '代金券使用时间',
  `status` smallint(2) unsigned NOT NULL DEFAULT '0' COMMENT '代金券使用状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `serial_num` (`serial_num`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='代金券表' ;

CREATE TABLE `jee_city_belong` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `types` varchar(10) COLLATE utf8_bin DEFAULT NULL COMMENT 'HOTEL,LINE,VIEWPOINT',
  `isdefault` int(11) DEFAULT '0',
  `isshow` smallint(2) NOT NULL DEFAULT '0' COMMENT '是否在频道页显示（1：是 0：否）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_comm_impr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `types` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_convert_money_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `types` varchar(20) NOT NULL,
  `totypes` varchar(20) NOT NULL,
  `addtime` datetime NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_draw_money` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '提现单ID号',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '提现用户ID号',
  `band_name` varchar(20) NOT NULL COMMENT '银行账户姓名',
  `band_code` varchar(24) NOT NULL COMMENT '银行账号',
  `person_code` varchar(23) DEFAULT NULL COMMENT '身份证号',
  `money` int(8) NOT NULL DEFAULT '0' COMMENT '提款金额',
  `phone_num` varchar(13) DEFAULT NULL COMMENT '手机号码',
  `remarks` varchar(300) NOT NULL COMMENT '备注',
  `bf_draw` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '提款前账户中的金额',
  `add_time` int(11) NOT NULL DEFAULT '0' COMMENT '下单时间',
  `status` smallint(2) NOT NULL DEFAULT '0' COMMENT '提款单状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_education_background` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `education` varchar(64) DEFAULT NULL COMMENT '教育背景',
  `status` int(11) DEFAULT '1' COMMENT '记录状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `send_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `receive` text NOT NULL,
  `send_time` int(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `att_id` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='短信发送记录' ;

CREATE TABLE `jee_email_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email_id` int(11) DEFAULT NULL,
  `send_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `email` text,
  `create_time` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `att_id` varchar(255) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `code` varchar(6) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='短信发送记录' ;

CREATE TABLE `jee_file_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) NOT NULL,
  `suffix` varchar(50) NOT NULL,
  `mime` varchar(30) NOT NULL,
  `path` varchar(255) NOT NULL,
  `size` int(11) DEFAULT NULL,
  `sort` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_fit_person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_goods_tag_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gtid` int(11) DEFAULT NULL,
  `gid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='标签与产品关系表' ;

CREATE TABLE `jee_goods_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(255) DEFAULT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `states` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='产品类型表' ;

CREATE TABLE `jee_hotel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `seo_id` int(11) DEFAULT '0',
  `hotel_chain_id` int(11) DEFAULT NULL,
  `hotel_type_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `video` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `open_time` int(11) DEFAULT NULL,
  `fix_time` int(11) DEFAULT '0',
  `address` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `contact` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `detail` text COLLATE utf8_bin,
  `traffic_info` text COLLATE utf8_bin,
  `around_info` text COLLATE utf8_bin,
  `location` text COLLATE utf8_bin,
  `tip` text COLLATE utf8_bin,
  `adds_service` text COLLATE utf8_bin,
  `paycart` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `special_service` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `service_item` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `service_dinner` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `recreation` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `room_facilitie` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `position` varchar(21) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_areabelong` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `business_circle` smallint(3) DEFAULT NULL COMMENT '商圈',
  `canton` smallint(3) DEFAULT NULL COMMENT '行政区',
  `subway_lines` smallint(3) DEFAULT NULL COMMENT '地铁线路',
  `station` smallint(3) DEFAULT NULL COMMENT '车站、机场',
  `sightseeing_spots` smallint(3) DEFAULT NULL COMMENT '观光景点',
  `college` smallint(3) DEFAULT NULL COMMENT '大学',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_chain` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `logopath` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_citybelong` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `city_id` int(11) NOT NULL,
  `area_name` varchar(25) NOT NULL,
  `area_type` smallint(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `hotel_id` int(11) NOT NULL COMMENT '收藏的景点',
  `user_id` int(11) NOT NULL COMMENT '景点收藏人',
  `create_time` datetime NOT NULL COMMENT '收藏时间',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '记录状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_impr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `room_id` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `impr_type` varchar(160) DEFAULT NULL,
  `decoration` smallint(3) NOT NULL DEFAULT '0',
  `traffic` smallint(3) NOT NULL DEFAULT '0',
  `hygiene` smallint(3) NOT NULL DEFAULT '0',
  `prices` smallint(3) NOT NULL DEFAULT '0',
  `content` varchar(400) DEFAULT NULL,
  `points` int(3) NOT NULL DEFAULT '100' COMMENT '满意度打分',
  `bonus_comm` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '实际给的点评奖金',
  `publish_time` int(11) NOT NULL,
  `show_name` smallint(2) NOT NULL DEFAULT '1' COMMENT '是否匿名（1：否 2：是）',
  `status` smallint(2) DEFAULT '1' COMMENT '未审核：1  已审核：2',
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `order_id` (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` varchar(17) NOT NULL,
  `user_id` int(11) NOT NULL,
  `room_id` int(11) NOT NULL,
  `come_date` int(11) NOT NULL,
  `leave_date` int(11) NOT NULL,
  `room_count` int(4) NOT NULL,
  `all_money` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '总共要支付的钱',
  `total` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '总价',
  `front_money` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '定金（预付金额）',
  `bonus_money` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '已使用的奖金',
  `serial_money` decimal(8,2) DEFAULT '0.00' COMMENT '已使用的代金券金额',
  `serial_num` varchar(32) DEFAULT NULL COMMENT '代金券编号',
  `pay_money` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '已支付的其他金额',
  `contact_name` varchar(12) NOT NULL,
  `contact_phone` varchar(12) NOT NULL,
  `contact_email` varchar(120) DEFAULT NULL,
  `arrive_time` int(11) NOT NULL,
  `special_want` varchar(160) DEFAULT NULL,
  `pay_status` smallint(2) DEFAULT NULL COMMENT '支付类型。1：全额支付 0：仅支付定金',
  `front_status` smallint(2) DEFAULT NULL COMMENT '订单状态改变前的状态',
  `status` smallint(2) NOT NULL,
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `picpath` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `istitlepage` int(11) DEFAULT '0' COMMENT '0不是封面，1是封面',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_que` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `question1` varchar(600) NOT NULL,
  `question2` varchar(1000) DEFAULT '',
  `answer` varchar(1600) DEFAULT NULL,
  `publish_time` int(12) NOT NULL,
  `answer_time` int(12) DEFAULT NULL,
  `status` smallint(2) DEFAULT '0',
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_room_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hotel_id` int(11) DEFAULT NULL,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `bed_type` int(11) DEFAULT NULL,
  `deal_type` int(11) DEFAULT NULL,
  `front_money` int(11) DEFAULT NULL,
  `bonus_comm` decimal(10,0) DEFAULT NULL,
  `room_count` int(5) DEFAULT NULL,
  `price_retail` decimal(10,0) DEFAULT NULL,
  `price_prefer` decimal(10,0) DEFAULT NULL,
  `price_special` decimal(10,0) DEFAULT NULL,
  `price_bonus_part` decimal(10,0) DEFAULT NULL,
  `date_limit_begin` int(11) DEFAULT NULL,
  `date_limit_end` int(11) DEFAULT NULL,
  `price_5` decimal(10,0) DEFAULT NULL,
  `price_6` decimal(10,0) DEFAULT NULL,
  `price_7` decimal(10,0) DEFAULT NULL,
  `breakfast` int(11) DEFAULT NULL,
  `broadband` int(11) DEFAULT NULL,
  `area` float DEFAULT NULL,
  `floor` int(11) DEFAULT NULL,
  `logopath` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `window` int(11) DEFAULT NULL,
  `bathroom` int(11) DEFAULT NULL,
  `extra_bed_price` decimal(10,0) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_hotel_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `picpath` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_incomes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code_id` varchar(25) NOT NULL,
  `money` decimal(13,2) NOT NULL DEFAULT '0.00',
  `now_money` decimal(13,2) NOT NULL DEFAULT '0.00',
  `types` tinyint(1) NOT NULL DEFAULT '0',
  `in_type` tinyint(1) NOT NULL DEFAULT '0',
  `create_time` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_industry_background` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `industry` varchar(64) DEFAULT NULL COMMENT '行业名',
  `parent_industry` int(11) DEFAULT NULL COMMENT '所属行业',
  `status` int(11) DEFAULT '1' COMMENT '记录状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `code` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `seo_id` int(11) DEFAULT '0',
  `line_type` int(11) DEFAULT NULL,
  `trip_days` int(11) DEFAULT NULL,
  `traffic` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `target_type` int(11) DEFAULT NULL,
  `target_topic` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `target` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `topic` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `deal_type` int(11) DEFAULT NULL,
  `award` int(11) DEFAULT NULL,
  `front_money` int(11) DEFAULT NULL,
  `bonus_comm` int(11) DEFAULT NULL,
  `property` int(11) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `edit_model` int(11) DEFAULT '1' COMMENT '编辑模式(1,按天，2,可视化)',
  `hits` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_impr` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT NULL,
  `impr_id` varchar(100) DEFAULT NULL,
  `travel` int(11) DEFAULT NULL,
  `guide` int(11) DEFAULT NULL,
  `traffic` int(11) DEFAULT NULL,
  `room` int(11) DEFAULT NULL,
  `point` int(11) DEFAULT NULL,
  `content` varchar(100) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `General` text COLLATE utf8_bin COMMENT '可视化模式的行程安排',
  `special_info` text COLLATE utf8_bin,
  `order_info` text COLLATE utf8_bin,
  `tip` text COLLATE utf8_bin,
  `contain` text COLLATE utf8_bin COMMENT '包含费用',
  `notcontain` text COLLATE utf8_bin COMMENT '不包含费用',
  `selfpay` text COLLATE utf8_bin COMMENT '自费项目',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_keep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `create_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `code` varchar(25) NOT NULL,
  `used_award` decimal(11,2) DEFAULT NULL,
  `used_card` varchar(25) DEFAULT NULL,
  `go_city` int(11) DEFAULT NULL,
  `go_time` int(11) DEFAULT NULL,
  `contact_name` varchar(25) DEFAULT NULL,
  `contact_num` varchar(25) DEFAULT NULL,
  `contact_email` varchar(25) DEFAULT NULL,
  `contact_msg` varchar(50) DEFAULT NULL,
  `review_award` decimal(11,2) DEFAULT NULL,
  `front_money` decimal(11,2) DEFAULT NULL,
  `amount` decimal(11,2) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL,
  `names` varchar(100) DEFAULT NULL COMMENT '图片标题',
  `pic_path` varchar(100) DEFAULT NULL COMMENT '原图',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `istitlepage` tinyint(1) DEFAULT NULL COMMENT '是否设置封面(1是2否)',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) DEFAULT NULL,
  `price_type` int(11) DEFAULT NULL COMMENT '价格类型，1指定日期，2起始日期和结束日期，3指定星期，4基本',
  `price_date` int(11) DEFAULT NULL COMMENT '当前价格日期',
  `price_date_end` int(11) DEFAULT NULL COMMENT '价格类型为阶段类型时的结束时间',
  `RACKRATE` decimal(20,2) DEFAULT NULL COMMENT '门市价',
  `price_adult` decimal(20,2) DEFAULT NULL COMMENT '成人价',
  `price_children` decimal(20,2) DEFAULT NULL COMMENT '儿童价',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_que` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `question1` varchar(600) NOT NULL,
  `question2` varchar(1000) DEFAULT '',
  `answer` varchar(1600) DEFAULT NULL,
  `publish_time` int(11) NOT NULL,
  `answer_time` int(11) DEFAULT NULL,
  `status` smallint(2) DEFAULT '1',
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_recommend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_id` int(11) NOT NULL,
  `area_id` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `start_id` int(11) NOT NULL COMMENT '目的地主题id',
  `type_id` int(11) DEFAULT NULL,
  `area_id` int(11) NOT NULL COMMENT '目的地城市ID',
  `travel_num` int(11) DEFAULT '0',
  `classify` int(11) DEFAULT NULL COMMENT '目的地分类',
  `sort` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='目的地城市' ;

CREATE TABLE `jee_line_topic_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_travel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) NOT NULL COMMENT '路线id',
  `day` int(11) DEFAULT NULL COMMENT '第几天',
  `title` varchar(255) DEFAULT NULL,
  `dining` varchar(10) DEFAULT NULL COMMENT '用餐(1,2,3)',
  `stay` varchar(50) DEFAULT NULL COMMENT '住宿',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_travel_section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `line_id` int(11) DEFAULT NULL,
  `travel_id` int(11) DEFAULT NULL,
  `names` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_line_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `page_names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `describe` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '类型描述',
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_liuyan` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(5) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `content` text NOT NULL,
  `contents` text,
  `admin_name` varchar(20) DEFAULT NULL,
  `user_time` datetime NOT NULL,
  `admin_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_mention` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `dedution` decimal(10,2) NOT NULL,
  `addtime` datetime NOT NULL,
  `memo` varchar(200) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_notice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `start_time` int(11) DEFAULT NULL,
  `end_time` int(11) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  `content` text,
  `hits` int(11) NOT NULL DEFAULT '0',
  `sort` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='公告管理' ;

CREATE TABLE `jee_order` (
  `id` int(11) NOT NULL,
  `order_id` varchar(50) NOT NULL,
  `addtime` datetime NOT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `jee_order_userinfo` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL COMMENT '订单表ID号（非订单号）',
  `names` varchar(16) NOT NULL COMMENT '用户姓名',
  `old_type` smallint(2) DEFAULT '1',
  `credentials` smallint(2) NOT NULL COMMENT '证件类型',
  `content` varchar(120) DEFAULT NULL COMMENT '信息内容',
  `type` varchar(10) NOT NULL COMMENT '信息所属分类（酒店、景点或线路）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_paycart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_payment_api` (
  `api_id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `names_en` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `merchantid` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `merchantkey` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `UDID` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_pwd` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payment_in` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fee` double NOT NULL,
  `sort` int(11) NOT NULL,
  `status` smallint(6) NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `configs` text COLLATE utf8_unicode_ci COMMENT '映射',
  PRIMARY KEY (`api_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8  ;

CREATE TABLE `jee_payment_bank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `api_id` int(11) NOT NULL,
  `names` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `types` tinyint(1) DEFAULT NULL,
  `key_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `mark` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `style` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `pic` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8  ;

CREATE TABLE `jee_payment_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `OrderId` varchar(50) NOT NULL,
  `POrderId` varchar(50) NOT NULL,
  `MerchantID` varchar(50) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `apiName` varchar(50) DEFAULT NULL,
  `AutoReceive` varchar(255) DEFAULT NULL,
  `Receive` varchar(255) DEFAULT NULL,
  `bank` varchar(15) DEFAULT NULL,
  `remark1` varchar(255) DEFAULT NULL,
  `remark2` varchar(255) DEFAULT NULL,
  `start_time` int(11) DEFAULT NULL,
  `finish_time` int(11) DEFAULT NULL,
  `browser` varchar(255) DEFAULT NULL,
  `status` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_payment_merchant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `merchant_name` varchar(50) NOT NULL,
  `MerchantID` varchar(20) DEFAULT NULL,
  `MerchantKey` varchar(64) DEFAULT NULL,
  `api_lists` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_recommend` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `obj_id` int(11) NOT NULL DEFAULT '0' COMMENT '目标项目的ID',
  `type` varchar(50) NOT NULL COMMENT '推荐项目类型（酒店、景点、路线等）',
  `rec_type` smallint(2) NOT NULL DEFAULT '1' COMMENT '推荐类型（1：特价推荐 2：热门推荐）',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '特价或热门价',
  `pic` varchar(150) NOT NULL COMMENT '图片路径',
  `content` varchar(1000) DEFAULT NULL COMMENT '推荐内容',
  `sort` int(11) NOT NULL DEFAULT '0' COMMENT '排序',
  `status` smallint(2) NOT NULL DEFAULT '1' COMMENT '状态（1：前台可见 2：前台不可见）',
  `add_time` int(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_recreation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_remittance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `bankname` varchar(20) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `addtime` datetime NOT NULL,
  `memo` varchar(200) DEFAULT NULL,
  `status` tinyint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE `jee_room_facilitie` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relate_id` int(11) DEFAULT NULL,
  `relate_table` varchar(50) DEFAULT NULL,
  `seo_title` varchar(200) DEFAULT NULL,
  `seo_keywords` varchar(255) DEFAULT NULL,
  `seo_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='seo表' ;

CREATE TABLE `jee_seo_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `keyword` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `detail` varchar(400) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_service_dinner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_service_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_singly` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) NOT NULL,
  `title` varchar(36) DEFAULT NULL,
  `text` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_sms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户id (当值为0时 表示发送的对象为全部会员)',
  `title` varchar(50) NOT NULL,
  `content` varchar(5000) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT '1',
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_sms_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_id` int(11) DEFAULT NULL,
  `send_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `phone` char(11) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  `content` text,
  `type` varchar(50) DEFAULT NULL,
  `code` varchar(6) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='短信发送记录' ;

CREATE TABLE `jee_special_service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_status_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `status_name` varchar(64) NOT NULL COMMENT '状态名',
  `apllication_scope` varchar(64) DEFAULT NULL COMMENT '使用范围',
  `status` int(11) DEFAULT NULL COMMENT '记录状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='状态类型表' ;

CREATE TABLE `jee_system_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `info` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_ticket_collector` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `cellphone` varchar(16) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_ticket_contactor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_name` varchar(256) NOT NULL,
  `contact_phone` varchar(16) DEFAULT NULL,
  `contact_email` varchar(256) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_ticket_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type_name` varchar(64) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `password` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `pay_password` varchar(50) COLLATE utf8_bin DEFAULT NULL COMMENT '支付密码',
  `email` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `amount` decimal(20,2) DEFAULT '0.00' COMMENT '账户余额',
  `award` decimal(13,2) NOT NULL DEFAULT '0.00',
  `create_time` int(11) DEFAULT NULL,
  `login_time` int(11) DEFAULT NULL,
  `login_ip` varchar(15) COLLATE utf8_bin DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_user_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `code_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `balance` decimal(10,2) NOT NULL,
  `mark` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `type` smallint(6) NOT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8  ;

CREATE TABLE `jee_user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `true_name` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `identity_no` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `avatar_path` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `sex` int(11) DEFAULT NULL,
  `tel` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `address` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `post_code` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `industry` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `education` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `income` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `marital_status` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_user_recharge` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `order_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL COMMENT '用户id',
  `code_id` varchar(20) COLLATE utf8_unicode_ci NOT NULL COMMENT '流水号',
  `money` decimal(10,2) NOT NULL COMMENT '充值金额',
  `api_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '接口名称',
  `bank_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '银行代号',
  `browser` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '客户端信息',
  `start_time` int(11) NOT NULL COMMENT '发起充值时间',
  `finish_time` int(11) NOT NULL COMMENT '完成充值时间',
  `status` smallint(6) NOT NULL COMMENT '状态：1：充值成功 2：充值失败 0：等待处理',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8  ;

CREATE TABLE `jee_user_tmp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `create_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `seo_id` int(11) DEFAULT '0',
  `city_id` int(11) DEFAULT NULL,
  `rank` int(11) DEFAULT NULL,
  `view_type` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `fit_person` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `video` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `view_address` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `tickets_address` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `contact` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `view_info` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `traffic_info` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `order_info` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `buy_info` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `position` varchar(21) COLLATE utf8_bin DEFAULT NULL COMMENT '经纬度坐标',
  `special_shopping` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `special_food` varchar(2000) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `hits` int(11) NOT NULL DEFAULT '0',
  `property` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `viewpoint_id` int(11) NOT NULL COMMENT '收藏的景点',
  `user_id` int(11) NOT NULL COMMENT '景点收藏人',
  `create_time` datetime NOT NULL COMMENT '收藏时间',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '记录状态：0禁用，1启用',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_impr` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `view_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `impr_type` varchar(160) DEFAULT NULL,
  `satisfaction` int(11) DEFAULT NULL,
  `decoration` smallint(3) NOT NULL DEFAULT '0',
  `traffic` smallint(3) NOT NULL DEFAULT '0',
  `hygiene` smallint(3) NOT NULL DEFAULT '0',
  `goods` smallint(3) NOT NULL DEFAULT '0',
  `prices` smallint(3) NOT NULL DEFAULT '0',
  `content` varchar(400) DEFAULT NULL,
  `show_name` int(2) DEFAULT '0' COMMENT '是否在评论中显示用户名',
  `points` int(11) DEFAULT NULL COMMENT '满意度',
  `publish_time` int(11) NOT NULL,
  `award` decimal(8,2) NOT NULL DEFAULT '0.00' COMMENT '实发点评奖金',
  `status` smallint(2) DEFAULT '1',
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `serial_num` varchar(32) NOT NULL COMMENT '订单编号',
  `ticket_id` varchar(120) DEFAULT NULL COMMENT '景点门票id',
  `ticket_num` int(11) DEFAULT '0' COMMENT '预定门票数量',
  `tour_date` datetime DEFAULT NULL,
  `all_money` decimal(11,2) NOT NULL DEFAULT '0.00' COMMENT '门票费用',
  `must_pay` decimal(11,2) NOT NULL DEFAULT '0.00',
  `use_award` int(11) DEFAULT '0' COMMENT '使用奖金',
  `pay_money` decimal(11,2) DEFAULT '0.00' COMMENT '已经支付的钱',
  `coupon_num` varchar(40) DEFAULT NULL COMMENT '使用代金券',
  `coupon_money` int(6) DEFAULT '0',
  `collector_id` int(11) DEFAULT NULL COMMENT '取票人信息，为空则为注册用户本人取票',
  `contactor_id` int(11) DEFAULT NULL COMMENT '联系人信息，为空则联系人是注册用户本人信息',
  `user_id` int(11) NOT NULL COMMENT '下单的注册用户',
  `special_requirement` varchar(512) DEFAULT NULL COMMENT '订票用户所提特殊要求',
  `collect_time` datetime DEFAULT NULL COMMENT '取票时间',
  `create_time` int(11) NOT NULL COMMENT '记录创建时间',
  `status_change_time` int(11) NOT NULL COMMENT '订单状态改变时间',
  `status_change_user` int(11) NOT NULL COMMENT '改变订单状态的用户',
  `status` int(11) NOT NULL DEFAULT '0' COMMENT '订单状态：0.待处理 1.待付款 2.已付款 3.已取票 4.已点评 5.已已结束 6.已取消',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_orderticket` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) DEFAULT '0',
  `ticket_id` int(11) NOT NULL,
  `ticket_count` int(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_pic` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `viewpoint_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `picpath` varchar(100) NOT NULL,
  `istitlepage` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `viewpoint_id` (`viewpoint_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_que` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `view_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `question1` varchar(600) NOT NULL,
  `question2` varchar(1000) DEFAULT '',
  `answer` varchar(1600) DEFAULT NULL,
  `publish_time` int(11) NOT NULL,
  `answer_time` int(11) DEFAULT NULL,
  `status` smallint(2) DEFAULT '1',
  `sort` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_rank` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rand` varchar(32) NOT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `viewpoint_id` int(11) NOT NULL COMMENT '景点id',
  `names` varchar(100) NOT NULL COMMENT '景点名称',
  `sort` int(11) NOT NULL COMMENT '排序',
  `deal_type` int(11) NOT NULL DEFAULT '1' COMMENT '处理方式(0人工处理 1自动处理)',
  `earnest` decimal(10,0) NOT NULL DEFAULT '100' COMMENT '定金百分比',
  `review_bonus` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '点评奖',
  `price` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '票面价',
  `inner_price` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '1到9 人优惠价格',
  `upon_price` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '10人以上优惠价格',
  `award_price` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '可使用奖金价格',
  `special_money` decimal(10,0) NOT NULL DEFAULT '0' COMMENT '特殊价',
  `begin_time` varchar(11) NOT NULL,
  `end_time` varchar(11) NOT NULL,
  `isdefault` int(11) NOT NULL DEFAULT '0' COMMENT '是否景点默认门票',
  `tatus` int(11) NOT NULL DEFAULT '1' COMMENT '（0隐藏 1显示）',
  `addtime` varchar(11) NOT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `viewpoint_id` (`viewpoint_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;

CREATE TABLE `jee_viewpoint_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `names` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 ;
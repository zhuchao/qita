<?php
import("ORG.Util.Page"); // 导入分页类
class imageAction extends CommonAction {
    
    //全部列表
    public function show_list() {
        echo '开发中...';exit;
    }
    
    

}
?>
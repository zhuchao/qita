<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Administrator
 * Date: 13-7-26
 * Time: 上午10:16
 * To change this template use File | Settings | File Templates.
 */
class jUploadAction extends Action {

}

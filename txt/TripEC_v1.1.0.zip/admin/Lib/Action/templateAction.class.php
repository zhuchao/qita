<?php
import("ORG.Util.Page"); // 导入分页类
class templateAction extends CommonAction {
    
    //模板列表
    public function show_list() {
        echo '暂未开发...';exit;
    }

}
?>
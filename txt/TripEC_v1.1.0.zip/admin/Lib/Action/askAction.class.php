<?php

import("ORG.Util.Page"); // 导入分页类

class askAction extends CommonAction {

    //线路点评列表
    public function line_list() {
        echo '受限于前台功能...';
        exit;
    }

    //景点点评列表
    public function viewpoint_list() {
        echo '受限于前台功能...';
        exit;
    }

    //酒店点评列表
    public function hotel_list() {
        echo '受限于前台功能...';
        exit;
    }

}

?>
<?php
import("ORG.Util.Page"); // 导入分页类
class otherAction extends CommonAction {
    //全部列表
    public function lists($messge) {
        
    }

}
?>
<?php

class OtherModel extends Model {

    //自动验证
    protected $_validate = array();
    
    //自动填充设置
    protected $_auto = array();

}

?>
<?php

return array(
    'thumbMaxWidth' => "600,300,100",
    'thumbMaxHeight' => "600,300,100",
);

?>

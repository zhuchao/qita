<?php

return array(
    'DB_TYPE' => 'mysql',
    'DB_HOST' => 'localhost',
    'DB_NAME' => 'TripEC_tags',
    'DB_USER' => 'root',
    'DB_PWD' => 'root',
    'DB_PORT' => '3306',
    'DB_PREFIX' => 'jee_',
    'DB_SUFFIX' => '',
    'APP_DEBUG' => 0,
    'MAIL_ADDRESS' => '', // 邮箱地址
    'MAIL_SMTP' => 'smtp.qq.com', // 邮箱SMTP服务器
    'MAIL_LOGINNAME' => '', // 邮箱登录帐号
    'MAIL_PASSWORD' => '', // 邮箱密码	
	
	"TRIPEC_VERSION" => "v1.1.0 Released", //版本号
	"TRIPEC_LICENSE" => "未授权", // 授权类型
	"TRIPEC_KEY" => "TRIPEC20140220", // 授权cd-key
	"TRIPEC_COPYRIGHT" => "2014", 
);
?>
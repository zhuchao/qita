<?php

return array(
	 "freeze_money" => 0, //是否冻结资金

	 "MerchantID" => 20140208, //商户号
	 "MerchantKey" => "aabbccddeeffgg", //密匙

	 "paymentAPI_Path" => "http://demo-v1.TripEC.cn/index.php/paymentapi/manage", //支付平台入口	 
);
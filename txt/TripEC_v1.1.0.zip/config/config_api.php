<?php

return array(
    "sms_api" => array(
        "sms_url" => "http://sdkhttp.eucp.b2m.cn/sdkproxy/",
        "sms_id" => "1061",
        "sms_cdkey" => "3SDK-EMY-0130-ODYNP",
        "sms_pwd" => "860172",
        "sms_model" => "1",
        "sms_stand" => "1:13557610774",
    ),
    "pay_model"=>1,
    "pay_debug_id"=>1,    
    "email_api" => array(
        "email_server" => "smtp.exmail.qq.com",
        "email_port" => "463",
        "email_user" => "TripEC@jeechange.com",
        "email_fromname" => "TripEC",
        "email_pwd" => "jeechange123",
        "email_charset" => "UTF-8",
        "email_return" => "TripEC@jeechange.com",
        "email_returnname" => "TripEC",
    ),
);
?>
